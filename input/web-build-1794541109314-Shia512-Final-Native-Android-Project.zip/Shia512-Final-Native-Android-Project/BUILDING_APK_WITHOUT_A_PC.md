# Shia512 — Android Debug APK Build Guide (Zero PC Required)

App developed by Syed Sadaf Hussain Zaidi

## Method 1: Free GitHub Actions Cloud Build (Recommended)
1. Download `Shia512-Final-Native-Android-Project.zip`.
2. Create a new repository on [github.com](https://github.com) using Chrome on your phone.
3. Upload the extracted files (making sure `.github/workflows/android-build.yml` is included) OR upload the ZIP archive + `.github/workflows/android-build.yml`.
4. Open the **Actions** tab on GitHub and tap **Run workflow** (or push to `main`).
5. Once the workflow completes (~2-3 minutes), download the **Shia512-Debug-APK** artifact and tap `app-debug.apk` to install directly on your Android phone.

## Method 2: Android Studio (Desktop)
1. Extract `Shia512-Final-Native-Android-Project.zip`.
2. Open the extracted folder in Android Studio.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
