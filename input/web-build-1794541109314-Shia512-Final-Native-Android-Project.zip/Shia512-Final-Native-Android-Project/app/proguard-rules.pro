# Keep Shia512 Alarm Receivers & Activity
-keep class com.shia512.app.alarm.** { *; }
-keep class com.shia512.app.ui.alarm.PrayerAlarmActivity { *; }
