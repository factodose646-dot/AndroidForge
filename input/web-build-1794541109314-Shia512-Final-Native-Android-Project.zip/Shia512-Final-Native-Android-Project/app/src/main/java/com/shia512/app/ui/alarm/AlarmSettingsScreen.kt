package com.shia512.app.ui.alarm

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.shia512.app.alarm.PrayerAlarmScheduler
import com.shia512.app.data.calculation.JafariCalculator
import com.shia512.app.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun AlarmSettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { UserPreferencesRepository(context) }
    val scheduler = remember { PrayerAlarmScheduler(context) }
    val prefs by repo.prefsFlow.collectAsState(initial = UserPreferencesRepository.DefaultPrefs)

    val cal = Calendar.getInstance()
    val tzOffsetHours = cal.timeZone.getOffset(cal.timeInMillis) / 3600000.0
    val timings = JafariCalculator.calculate(
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH) + 1,
        cal.get(Calendar.DAY_OF_MONTH),
        prefs.latitude,
        prefs.longitude,
        tzOffsetHours,
        prefs.isTehranMethod
    )
    val nextReminder = JafariCalculator.findNextPrayer(cal, timings, prefs)

    var hasNotifPerm by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotifPerm = granted
    }

    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) alarmManager.canScheduleExactAlarms() else true
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val canFullScreen = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) nm.canUseFullScreenIntent() else true

    fun updateAndReschedule(block: suspend () -> Unit) {
        scope.launch {
            block()
            scheduler.rescheduleAllFromPreferences()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF20080D)),
                border = BorderStroke(1.5.dp, Color(0xFFFF1A35)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("NEXT SCHEDULED PRAYER REMINDER", color = Color(0xFFFF4D64), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("${nextReminder.first} at ${nextReminder.second}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("City: ${prefs.cityName}", color = Color(0xFFA1A1AA), fontSize = 12.sp)
                }
            }
        }

        // Individual Prayer ON/OFF Toggles
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF100E14)),
                border = BorderStroke(1.dp, Color(0xFF2B1217)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Individual Prayer Reminders", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(8.dp))

                    PrayerSwitchRow("Fajr", JafariCalculator.formatHourMinutes(timings.fajr), prefs.fajrEnabled) { v ->
                        updateAndReschedule { repo.setPrayerEnabled("fajr", v) }
                    }
                    PrayerSwitchRow("Dhuhr", JafariCalculator.formatHourMinutes(timings.dhuhr), prefs.dhuhrEnabled) { v ->
                        updateAndReschedule { repo.setPrayerEnabled("dhuhr", v) }
                    }
                    PrayerSwitchRow("Asr", JafariCalculator.formatHourMinutes(timings.asr), prefs.asrEnabled) { v ->
                        updateAndReschedule { repo.setPrayerEnabled("asr", v) }
                    }
                    PrayerSwitchRow("Maghrib", JafariCalculator.formatHourMinutes(timings.maghrib), prefs.maghribEnabled) { v ->
                        updateAndReschedule { repo.setPrayerEnabled("maghrib", v) }
                    }
                    PrayerSwitchRow("Isha", JafariCalculator.formatHourMinutes(timings.isha), prefs.ishaEnabled) { v ->
                        updateAndReschedule { repo.setPrayerEnabled("isha", v) }
                    }
                }
            }
        }

        // Sound, Vibration, Tone & Snooze Settings
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF100E14)),
                border = BorderStroke(1.dp, Color(0xFF2B1217)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sound, Vibration & Snooze", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Alarm Sound", color = Color(0xFFE4E4E7))
                        Switch(checked = prefs.soundEnabled, onCheckedChange = { scope.launch { repo.setSoundEnabled(it) } })
                    }

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Vibration", color = Color(0xFFE4E4E7))
                        Switch(checked = prefs.vibrationEnabled, onCheckedChange = { scope.launch { repo.setVibrationEnabled(it) } })
                    }

                    Text("Alarm Tone Selection", color = Color(0xFFA1A1AA), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("adhan_chime" to "Islamic Tone", "system_alarm" to "Default Alarm", "soft_ring" to "Gentle Ring").forEach { (id, label) ->
                            FilterChip(
                                selected = prefs.alarmTone == id,
                                onClick = { scope.launch { repo.setAlarmTone(id) } },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    Text("Snooze Duration", color = Color(0xFFA1A1AA), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10).forEach { mins ->
                            FilterChip(
                                selected = prefs.snoozeMinutes == mins,
                                onClick = { scope.launch { repo.setSnoozeMinutes(mins) } },
                                label = { Text("$mins Minutes") }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val testIntent = Intent(context, PrayerAlarmActivity::class.java).apply {
                                putExtra("PRAYER_ID", "test")
                                putExtra("PRAYER_NAME", nextReminder.first)
                            }
                            context.startActivity(testIntent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1A35)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Test Full-Screen Red Neon Alarm", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Android 12/13/14 Permissions Panel (Honest Disclosure & Settings Launchers)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF160B0F)),
                border = BorderStroke(1.dp, Color(0xFF3D1820)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Android Alarm Permissions", color = Color(0xFFFF4D64), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        "Android restricts locked-screen popups and exact wake alarms unless explicitly permitted. If full-screen access is denied, Shia512 posts a high-priority alarm notification with sound and vibration.",
                        color = Color(0xFFA1A1AA),
                        fontSize = 11.sp
                    )

                    if (!hasNotifPerm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Button(onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Grant Notification Permission (Android 13+)")
                        }
                    }

                    if (!canExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Allow Exact Alarms in Settings", color = Color.White)
                        }
                    }

                    if (!canFullScreen && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Allow Full-Screen Lock Alarm (Android 14+)", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PrayerSwitchRow(name: String, time: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(name, color = Color.White, fontWeight = FontWeight.Bold)
            Text(time, color = Color(0xFFA1A1AA), fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
