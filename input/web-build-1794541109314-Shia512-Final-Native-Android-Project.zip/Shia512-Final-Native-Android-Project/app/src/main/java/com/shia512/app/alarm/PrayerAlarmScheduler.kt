package com.shia512.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shia512.app.data.calculation.JafariCalculator
import com.shia512.app.data.preferences.UserPreferencesRepository
import java.util.Calendar

class PrayerAlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    companion object {
        private val PRAYER_CODES = mapOf(
            "fajr" to 51201,
            "dhuhr" to 51202,
            "asr" to 51203,
            "maghrib" to 51204,
            "isha" to 51205,
            "snooze" to 51299
        )
    }

    suspend fun rescheduleAllFromPreferences() {
        val repo = UserPreferencesRepository(context)
        val prefs = repo.getSnapshot()

        val nowCal = Calendar.getInstance()
        val nowMillis = nowCal.timeInMillis
        val tzOffsetHours = nowCal.timeZone.getOffset(nowMillis) / 3600000.0

        val todayTimings = JafariCalculator.calculate(
            nowCal.get(Calendar.YEAR),
            nowCal.get(Calendar.MONTH) + 1,
            nowCal.get(Calendar.DAY_OF_MONTH),
            prefs.latitude,
            prefs.longitude,
            tzOffsetHours,
            prefs.isTehranMethod
        )

        val tomorrowCal = (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
        val tomorrowTimings = JafariCalculator.calculate(
            tomorrowCal.get(Calendar.YEAR),
            tomorrowCal.get(Calendar.MONTH) + 1,
            tomorrowCal.get(Calendar.DAY_OF_MONTH),
            prefs.latitude,
            prefs.longitude,
            tomorrowCal.timeZone.getOffset(tomorrowCal.timeInMillis) / 3600000.0,
            prefs.isTehranMethod
        )

        val prayers = listOf(
            Triple("fajr", "Fajr", Pair(prefs.fajrEnabled, todayTimings.fajr to tomorrowTimings.fajr)),
            Triple("dhuhr", "Dhuhr", Pair(prefs.dhuhrEnabled, todayTimings.dhuhr to tomorrowTimings.dhuhr)),
            Triple("asr", "Asr", Pair(prefs.asrEnabled, todayTimings.asr to tomorrowTimings.asr)),
            Triple("maghrib", "Maghrib", Pair(prefs.maghribEnabled, todayTimings.maghrib to tomorrowTimings.maghrib)),
            Triple("isha", "Isha", Pair(prefs.ishaEnabled, todayTimings.isha to tomorrowTimings.isha))
        )

        for ((id, name, config) in prayers) {
            val (enabled, hoursPair) = config
            cancelAlarm(id) // Always cancel first to prevent duplicate alarms
            if (!enabled) continue

            val todayMillis = JafariCalculator.decimalHourToMillisToday(nowCal, hoursPair.first)
            val triggerMillis = if (todayMillis > nowMillis + 2000L) {
                todayMillis
            } else {
                JafariCalculator.decimalHourToMillisToday(tomorrowCal, hoursPair.second)
            }
            scheduleExactPrayerAlarm(id, name, triggerMillis)
        }
    }

    fun scheduleExactPrayerAlarm(prayerId: String, prayerName: String, triggerTimeMillis: Long) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = "com.shia512.app.ACTION_PRAYER_ALARM"
            putExtra("PRAYER_ID", prayerId)
            putExtra("PRAYER_NAME", prayerName)
        }

        val requestCode = PRAYER_CODES[prayerId.lowercase()] ?: prayerId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else true

        if (canExact) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMillis, pendingIntent)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMillis, pendingIntent)
        }
    }

    fun scheduleSnoozeAlarm(prayerName: String, snoozeMinutes: Int) {
        cancelAlarm("snooze")
        val triggerMillis = System.currentTimeMillis() + (snoozeMinutes * 60_000L)
        scheduleExactPrayerAlarm("snooze", prayerName, triggerMillis)
    }

    fun cancelAlarm(prayerId: String) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = "com.shia512.app.ACTION_PRAYER_ALARM"
        }
        val requestCode = PRAYER_CODES[prayerId.lowercase()] ?: prayerId.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
