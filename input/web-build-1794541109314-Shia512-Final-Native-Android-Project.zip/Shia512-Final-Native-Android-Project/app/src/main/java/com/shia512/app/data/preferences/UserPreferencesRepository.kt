package com.shia512.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "shia512_prefs")

class UserPreferencesRepository(private val context: Context) {

    data class Prefs(
        val cityName: String = "Lahore",
        val countryName: String = "Pakistan",
        val latitude: Double = 31.5204,
        val longitude: Double = 74.3587,
        val isTehranMethod: Boolean = false,
        val fajrEnabled: Boolean = true,
        val dhuhrEnabled: Boolean = true,
        val asrEnabled: Boolean = true,
        val maghribEnabled: Boolean = true,
        val ishaEnabled: Boolean = true,
        val soundEnabled: Boolean = true,
        val vibrationEnabled: Boolean = true,
        val alarmTone: String = "adhan_chime",
        val snoozeMinutes: Int = 5,
        val tasbeehCount: Int = 0
    )

    companion object {
        val DefaultPrefs = Prefs()
        private val KEY_CITY = stringPreferencesKey("city_name")
        private val KEY_COUNTRY = stringPreferencesKey("country_name")
        private val KEY_LAT = doublePreferencesKey("latitude")
        private val KEY_LNG = doublePreferencesKey("longitude")
        private val KEY_TEHRAN = booleanPreferencesKey("is_tehran")
        private val KEY_FAJR = booleanPreferencesKey("alarm_fajr")
        private val KEY_DHUHR = booleanPreferencesKey("alarm_dhuhr")
        private val KEY_ASR = booleanPreferencesKey("alarm_asr")
        private val KEY_MAGHRIB = booleanPreferencesKey("alarm_maghrib")
        private val KEY_ISHA = booleanPreferencesKey("alarm_isha")
        private val KEY_SOUND = booleanPreferencesKey("sound_enabled")
        private val KEY_VIBRATION = booleanPreferencesKey("vibration_enabled")
        private val KEY_TONE = stringPreferencesKey("alarm_tone")
        private val KEY_SNOOZE = intPreferencesKey("snooze_minutes")
        private val KEY_TASBEEH = intPreferencesKey("tasbeeh_count")
    }

    val prefsFlow: Flow<Prefs> = context.dataStore.data.map { p ->
        Prefs(
            cityName = p[KEY_CITY] ?: "Lahore",
            countryName = p[KEY_COUNTRY] ?: "Pakistan",
            latitude = p[KEY_LAT] ?: 31.5204,
            longitude = p[KEY_LNG] ?: 74.3587,
            isTehranMethod = p[KEY_TEHRAN] ?: false,
            fajrEnabled = p[KEY_FAJR] ?: true,
            dhuhrEnabled = p[KEY_DHUHR] ?: true,
            asrEnabled = p[KEY_ASR] ?: true,
            maghribEnabled = p[KEY_MAGHRIB] ?: true,
            ishaEnabled = p[KEY_ISHA] ?: true,
            soundEnabled = p[KEY_SOUND] ?: true,
            vibrationEnabled = p[KEY_VIBRATION] ?: true,
            alarmTone = p[KEY_TONE] ?: "adhan_chime",
            snoozeMinutes = p[KEY_SNOOZE] ?: 5,
            tasbeehCount = p[KEY_TASBEEH] ?: 0
        )
    }

    suspend fun getSnapshot(): Prefs = prefsFlow.first()

    suspend fun setLocation(city: String, country: String, lat: Double, lng: Double) {
        context.dataStore.edit {
            it[KEY_CITY] = city
            it[KEY_COUNTRY] = country
            it[KEY_LAT] = lat
            it[KEY_LNG] = lng
        }
    }

    suspend fun setCalculationMethod(isTehran: Boolean) {
        context.dataStore.edit { it[KEY_TEHRAN] = isTehran }
    }

    suspend fun setPrayerEnabled(prayerId: String, enabled: Boolean) {
        context.dataStore.edit {
            when (prayerId.lowercase()) {
                "fajr" -> it[KEY_FAJR] = enabled
                "dhuhr" -> it[KEY_DHUHR] = enabled
                "asr" -> it[KEY_ASR] = enabled
                "maghrib" -> it[KEY_MAGHRIB] = enabled
                "isha" -> it[KEY_ISHA] = enabled
            }
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SOUND] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_VIBRATION] = enabled }
    }

    suspend fun setAlarmTone(tone: String) {
        context.dataStore.edit { it[KEY_TONE] = tone }
    }

    suspend fun setSnoozeMinutes(minutes: Int) {
        context.dataStore.edit { it[KEY_SNOOZE] = minutes }
    }

    suspend fun setTasbeehCount(count: Int) {
        context.dataStore.edit { it[KEY_TASBEEH] = count }
    }
}
