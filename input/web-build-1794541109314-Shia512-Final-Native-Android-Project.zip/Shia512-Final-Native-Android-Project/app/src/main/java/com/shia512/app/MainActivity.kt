package com.shia512.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.lifecycleScope
import com.shia512.app.alarm.PrayerAlarmScheduler
import com.shia512.app.ui.alarm.AlarmSettingsScreen
import com.shia512.app.ui.calendar.CalendarScreen
import com.shia512.app.ui.farman.FarmanScreen
import com.shia512.app.ui.home.HomeScreen
import com.shia512.app.ui.settings.SettingsScreen
import com.shia512.app.ui.tasbeeh.TasbeehScreen
import com.shia512.app.ui.theme.Shia512Theme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Ensure all enabled prayer alarms are scheduled on launch
        lifecycleScope.launch {
            PrayerAlarmScheduler(applicationContext).rescheduleAllFromPreferences()
        }

        setContent {
            Shia512Theme {
                MainAppScaffold()
            }
        }
    }
}

@Composable
fun MainAppScaffold() {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = Color(0xFF050507),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0A0A0E),
                contentColor = Color(0xFFFF1A35)
            ) {
                val items = listOf(
                    Triple(0, "Home", Icons.Default.Home),
                    Triple(1, "Farman", Icons.Default.MenuBook),
                    Triple(2, "Alarms", Icons.Default.Alarm),
                    Triple(3, "Tasbeeh", Icons.Default.TouchApp),
                    Triple(4, "Calendar", Icons.Default.CalendarMonth),
                    Triple(5, "Settings", Icons.Default.Settings)
                )

                items.forEach { (index, title, icon) ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(icon, contentDescription = title) },
                        label = { Text(title, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFFF1A35),
                            selectedTextColor = Color(0xFFFF1A35),
                            unselectedIconColor = Color(0xFF71717A),
                            unselectedTextColor = Color(0xFF71717A),
                            indicatorColor = Color(0x33FF1A35)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> HomeScreen(
                    onOpenFarman = { selectedTab = 1 },
                    onOpenTasbeeh = { selectedTab = 3 },
                    onOpenAlarms = { selectedTab = 2 }
                )
                1 -> FarmanScreen()
                2 -> AlarmSettingsScreen()
                3 -> TasbeehScreen()
                4 -> CalendarScreen()
                5 -> SettingsScreen()
            }
        }
    }
}
