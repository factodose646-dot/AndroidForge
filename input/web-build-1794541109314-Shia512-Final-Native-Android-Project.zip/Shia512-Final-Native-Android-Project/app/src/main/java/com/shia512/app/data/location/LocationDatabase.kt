package com.shia512.app.data.location

object LocationDatabase {
    data class CityItem(
        val name: String,
        val country: String,
        val lat: Double,
        val lng: Double
    )

    val CITIES = listOf(
        CityItem("Lahore", "Pakistan", 31.5204, 74.3587),
        CityItem("Karachi", "Pakistan", 24.8607, 67.0011),
        CityItem("Islamabad", "Pakistan", 33.6844, 73.0479),
        CityItem("Rawalpindi", "Pakistan", 33.5651, 73.0169),
        CityItem("Faisalabad", "Pakistan", 31.4504, 73.1350),
        CityItem("Sargodha", "Pakistan", 32.0740, 72.6861),
        CityItem("Khushab", "Pakistan", 32.2955, 72.3489),
        CityItem("Bhalwal", "Pakistan", 32.2653, 72.8981),
        CityItem("Multan", "Pakistan", 30.1575, 71.5249),
        CityItem("Najaf al-Ashraf", "Iraq", 32.0000, 44.3360),
        CityItem("Karbala al-Muqaddasa", "Iraq", 32.6160, 44.0249),
        CityItem("Mashhad", "Iran", 36.2605, 59.6168),
        CityItem("Qom", "Iran", 34.6416, 50.8746)
    )
}
