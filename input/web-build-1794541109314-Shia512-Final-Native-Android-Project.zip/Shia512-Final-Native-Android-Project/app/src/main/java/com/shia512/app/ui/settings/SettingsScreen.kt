package com.shia512.app.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shia512.app.alarm.PrayerAlarmScheduler
import com.shia512.app.data.location.LocationDatabase
import com.shia512.app.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { UserPreferencesRepository(context) }
    val scheduler = remember { PrayerAlarmScheduler(context) }
    val prefs by repo.prefsFlow.collectAsState(initial = UserPreferencesRepository.DefaultPrefs)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14090D)),
                border = BorderStroke(1.dp, Color(0xFF2B1217)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Shia Ja'fari Calculation Method", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !prefs.isTehranMethod,
                            onClick = {
                                scope.launch {
                                    repo.setCalculationMethod(false)
                                    scheduler.rescheduleAllFromPreferences()
                                }
                            },
                            label = { Text("Leva Qom (16°/4.5°)") }
                        )
                        FilterChip(
                            selected = prefs.isTehranMethod,
                            onClick = {
                                scope.launch {
                                    repo.setCalculationMethod(true)
                                    scheduler.rescheduleAllFromPreferences()
                                }
                            },
                            label = { Text("Tehran (17.7°/4.5°)") }
                        )
                    }
                }
            }
        }

        item {
            Text("Select Offline Location", color = Color(0xFFFF4D64), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        items(LocationDatabase.CITIES) { city ->
            val selected = city.name == prefs.cityName
            Card(
                colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF2B0C12) else Color(0xFF0E0E13)),
                border = BorderStroke(1.dp, if (selected) Color(0xFFFF1A35) else Color(0xFF231215)),
                shape = RoundedCornerShape(12.dp),
                onClick = {
                    scope.launch {
                        repo.setLocation(city.name, city.country, city.lat, city.lng)
                        scheduler.rescheduleAllFromPreferences()
                    }
                }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(city.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(city.country, color = Color(0xFFA1A1AA), fontSize = 11.sp)
                    }
                    if (selected) {
                        Text("Selected", color = Color(0xFFFF1A35), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // About App & App Information Card with Exact Developer Credit
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF16080C)),
                border = BorderStroke(1.5.dp, Color(0x88FF1A35)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("About Shia512 — App Information", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text(
                        "Shia512 is a lightweight, battery-efficient Shia Ithna Ashari (Ja'fari) application built with Jetpack Compose for offline prayer times, Farman-e-Masoomeen, Digital Tasbeeh, and exact native AlarmManager reminders.",
                        color = Color(0xFFD4D4D8),
                        fontSize = 12.sp
                    )
                    HorizontalDivider(color = Color(0xFF301319), modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "App developed by Syed Sadaf Hussain Zaidi",
                        color = Color(0xFFFF4D64),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
