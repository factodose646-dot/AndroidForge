package com.shia512.app.data.farman

import java.util.Calendar

data class Farman(
    val id: Int,
    val masoomEn: String,
    val masoomUr: String,
    val arabic: String,
    val urdu: String,
    val english: String,
    val source: String
)

object FarmanRepository {
    private val FARMANS = listOf(
        Farman(1, "Prophet Muhammad (PBUH)", "حضرت محمد مصطفیٰ صلی اللہ علیہ و آلہ وسلم",
            "إِنِّي تَارِكٌ فِيكُمُ الثَّقَلَيْنِ كِتَابَ اللَّهِ وَعِتْرَتِي أَهْلَ بَيْتِي",
            "میں تمہارے درمیان دو گراں قدر چیزیں چھوڑے جا رہا ہوں: ایک اللہ کی کتاب اور دوسری میری عترت یعنی میرے اہل بیت۔",
            "I leave among you two weighty things: the Book of Allah and my progeny, my Ahlulbayt.",
            "Al-Kafi, Vol. 1, p. 294; Sahih Muslim, Hadith 2408"),
        Farman(2, "Bibi Fatima Zahra (S.A.)", "سیدہ فاطمۃ الزہراء سلام اللہ علیہا",
            "فَرَضَ اللَّهُ الصَّلَاةَ تَنْزِيهاً عَنِ الْكِبْرِ",
            "اللہ تعالیٰ نے تکبر اور غرور کی پاکیزگی کے لیے نماز کو واجب قرار دیا۔",
            "Allah made prayer obligatory to purify mankind from arrogance.",
            "Al-Ihtijaj by al-Tabarsi, Vol. 1, p. 134 (Fadak Sermon)"),
        Farman(3, "Imam Ali (A.S.)", "امیر المومنین امام علی علیہ السلام",
            "قِيمَةُ كُلِّ امْرِئٍ مَا يُحْسِنُهُ",
            "ہر انسان کی قدر و قیمت وہ ہنر اور خوبی ہے جس میں وہ مہارت رکھتا ہے۔",
            "The true value of every person lies in what good they do best.",
            "Nahj al-Balagha, Saying 81"),
        Farman(4, "Imam Hasan (A.S.)", "امام حسن مجتبیٰ علیہ السلام",
            "إِنَّ أَبْصَرَ الْأَبْصَارِ مَا نَفَذَ فِي الْخَيْرِ مَذْهَبُهُ",
            "بے شک سب سے روشن بصیرت وہ ہے جو نیکی اور بھلائی کے راستے پر گامزن ہو۔",
            "Surely the keenest vision is that which penetrates deeply into the path of goodness.",
            "Tuhaf al-Uqul, p. 235"),
        Farman(5, "Imam Hussain (A.S.)", "سید الشہداء امام حسین علیہ السلام",
            "إِنِّي لَا أَرَى الْمَوْتَ إِلَّا سَعَادَةً وَالْحَيَاةَ مَعَ الظَّالِمِينَ إِلَّا بَرَماً",
            "میں عزت کی موت کو سعادت اور ظالموں کے سائے میں جینے کو ذلت و تنگی سمجھتا ہوں۔",
            "I see death with dignity as naught but felicity, and living with oppressors as nothing but humiliation.",
            "Tuhaf al-Uqul, p. 245; Bihar al-Anwar, Vol. 44, p. 381"),
        Farman(6, "Imam Zain-ul-Abideen (A.S.)", "امام زین العابدین علیہ السلام",
            "حَقُّ الصَّلَاةِ أَنْ تَعْلَمَ أَنَّهَا وِفَادَةٌ إِلَى اللَّهِ",
            "نماز کا حق یہ ہے کہ تم جان لو کہ یہ اللہ تعالیٰ کی بارگاہ میں حاضری ہے۔",
            "The right of prayer is that you know it is an audience before Allah.",
            "Risalat al-Huquq; Al-Khisal, Vol. 2, p. 564"),
        Farman(7, "Imam Muhammad Baqir (A.S.)", "امام محمد باقر علیہ السلام",
            "مَنْ صَدَقَ لِسَانُهُ زَكَا عَمَلُهُ",
            "جس شخص کی زبان سچی ہوتی ہے اس کا عمل پاکیزہ ہو جاتا ہے۔",
            "Whoever speaks truthfully, their deeds become purified.",
            "Al-Kafi, Vol. 2, p. 105; Tuhaf al-Uqul, p. 298"),
        Farman(8, "Imam Jafar Sadiq (A.S.)", "امام جعفر صادق علیہ السلام",
            "لَا تَنَالُ شَفَاعَتُنَا مَنِ اسْتَخَفَّ بِالصَّلَاةِ",
            "ہماری شفاعت اس شخص تک نہیں پہنچے گی جو نماز کو ہلکا یا حقیر سمجھے۔",
            "Our intercession shall never reach the one who takes prayer lightly.",
            "Al-Kafi, Vol. 3, p. 268, Hadith 6"),
        Farman(9, "Imam Musa Kazim (A.S.)", "امام موسیٰ کاظم علیہ السلام",
            "لَيْسَ مِنَّا مَنْ لَمْ يُحَاسِبْ نَفْسَهُ فِي كُلِّ يَوْمٍ",
            "وہ ہم میں سے نہیں جو ہر روز اپنے نفس کا محاسبہ نہ کرے۔",
            "He is not of us who does not take account of his own soul every single day.",
            "Al-Kafi, Vol. 2, p. 453, Hadith 2"),
        Farman(10, "Imam Ali Raza (A.S.)", "امام علی رضا علیہ السلام",
            "صَدِيقُ كُلِّ امْرِئٍ عَقْلُهُ وَعَدُوُّهُ جَهْلُهُ",
            "ہر انسان کا بہترین دوست اس کی عقل ہے اور اس کا دشمن اس کی جہالت ہے۔",
            "Every person's truest friend is their intellect, and their worst enemy is their ignorance.",
            "Uyun Akhbar al-Rida, Vol. 2, p. 2; Al-Kafi, Vol. 1, p. 11"),
        Farman(11, "Imam Muhammad Taqi (A.S.)", "امام محمد تقی الجواد علیہ السلام",
            "الْمُؤْمِنُ يَحْتَاجُ إِلَى تَوْفِيقٍ مِنَ اللَّهِ وَوَاعِظٍ مِنْ نَفْسِهِ",
            "مومن کو اللہ کی توفیق اور اپنے اندر ایک نصیحت کرنے والے ضمیر کی ضرورت ہوتی ہے۔",
            "A believer needs divine guidance from Allah and an inner admonisher from within.",
            "Tuhaf al-Uqul, p. 457"),
        Farman(12, "Imam Ali Naqi (A.S.)", "امام علی نقی الہادی علیہ السلام",
            "الدُّنْيَا سُوقٌ رَبِحَ فِيهَا قَوْمٌ وَخَسِرَ آخَرُونَ",
            "دنیا ایک بازار ہے جس میں ایک گروہ نے نفع کمایا اور دوسرے نے نقصان اٹھایا۔",
            "This world is a marketplace in which some people gain profit and others suffer loss.",
            "Tuhaf al-Uqul, p. 483"),
        Farman(13, "Imam Hasan Askari (A.S.)", "امام حسن عسکری علیہ السلام",
            "خَيْرُ إِخْوَانِكَ مَنْ نَسِيَ ذَنْبَكَ وَذَكَرَ إِحْسَانَكَ إِلَيْهِ",
            "تمہارا بہترین بھائی وہ ہے جو تمہاری غلطی بھول جائے اور تمہارے احسان کو یاد رکھے۔",
            "The best of your brothers is the one who forgets your fault against him and remembers your kindness.",
            "Bihar al-Anwar, Vol. 75, p. 377"),
        Farman(14, "Imam Muhammad Mahdi (A.J.)", "امام زمانہ حضرت مہدی علیہ السلام",
            "إِنَّا غَيْرُ مُهْمِلِينَ لِمُرَاعَاتِكُمْ وَلَا نَاسِينَ لِذِكْرِكُمْ",
            "ہم تمہاری خبر گیری سے غافل نہیں ہیں اور نہ ہی تمہارے ذکر کو بھولے ہیں۔",
            "We are neither neglectful of your affairs nor forgetful of remembering you.",
            "Al-Ihtijaj by al-Tabarsi, Vol. 2, p. 497; Bihar al-Anwar, Vol. 53, p. 175")
    )

    fun getDailyFarman(): Farman {
        val cal = Calendar.getInstance()
        val index = ((cal.get(Calendar.YEAR) * 365 + cal.get(Calendar.DAY_OF_YEAR)) % FARMANS.size).coerceAtLeast(0)
        return FARMANS[index]
    }

    fun getAllFarmans(): List<Farman> = FARMANS
}
