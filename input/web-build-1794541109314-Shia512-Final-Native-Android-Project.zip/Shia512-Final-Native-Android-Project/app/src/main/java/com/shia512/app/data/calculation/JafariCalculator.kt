package com.shia512.app.data.calculation

import com.shia512.app.data.preferences.UserPreferencesRepository
import java.util.Calendar
import kotlin.math.*

object JafariCalculator {

    data class PrayerTimings(
        val fajr: Double,
        val sunrise: Double,
        val dhuhr: Double,
        val asr: Double,
        val sunset: Double,
        val maghrib: Double,
        val isha: Double,
        val midnight: Double
    )

    private fun degToRad(deg: Double): Double = (deg * Math.PI) / 180.0
    private fun radToDeg(rad: Double): Double = (rad * 180.0) / Math.PI

    private fun fixAngle(angle: Double): Double {
        var a = angle - 360.0 * floor(angle / 360.0)
        if (a < 0) a += 360.0
        return a
    }

    private fun fixHour(hour: Double): Double {
        var h = hour - 24.0 * floor(hour / 24.0)
        if (h < 0) h += 24.0
        return h
    }

    fun calculate(
        year: Int,
        month: Int,
        day: Int,
        latitude: Double,
        longitude: Double,
        tzOffsetHours: Double,
        isTehranMethod: Boolean = false
    ): PrayerTimings {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        val jd = floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
        val d = jd - 2451545.0

        val meanAnomaly = fixAngle(357.529 + 0.98560028 * d)
        val meanLongitude = fixAngle(280.459 + 0.98564736 * d)
        val center = 1.915 * sin(degToRad(meanAnomaly)) + 0.02 * sin(degToRad(2 * meanAnomaly))
        val eclipticLongitude = fixAngle(meanLongitude + center)

        val obliquity = 23.439 - 0.00000036 * d
        val sinDelta = sin(degToRad(obliquity)) * sin(degToRad(eclipticLongitude))
        val declination = radToDeg(asin(sinDelta))

        val tanAlpha = cos(degToRad(obliquity)) * tan(degToRad(eclipticLongitude))
        var alpha = radToDeg(atan(tanAlpha))
        if (cos(degToRad(eclipticLongitude)) < 0) alpha += 180.0
        else if (sin(degToRad(eclipticLongitude)) < 0) alpha += 360.0
        alpha = fixAngle(alpha)

        val equationOfTime = (meanLongitude - alpha) / 15.0
        val dhuhr = fixHour(12.0 + tzOffsetHours - longitude / 15.0 - equationOfTime)

        val fajrAngle = if (isTehranMethod) 17.7 else 16.0
        val sunriseAngle = 0.833
        val maghribAngle = 4.5
        val ishaAngle = 14.0

        fun hourAngle(angle: Double): Double {
            val latRad = degToRad(latitude)
            val decRad = degToRad(declination)
            val cosH = (sin(degToRad(-angle)) - sin(latRad) * sin(decRad)) / (cos(latRad) * cos(decRad))
            return radToDeg(acos(cosH.coerceIn(-1.0, 1.0))) / 15.0
        }

        val middayZenith = abs(latitude - declination)
        val asrAltitude = radToDeg(atan(1.0 / (1.0 + tan(degToRad(middayZenith)))))
        val asrCosH = (sin(degToRad(asrAltitude)) - sin(degToRad(latitude)) * sin(degToRad(declination))) /
            (cos(degToRad(latitude)) * cos(degToRad(declination)))
        val asrHA = radToDeg(acos(asrCosH.coerceIn(-1.0, 1.0))) / 15.0

        val fajr = fixHour(dhuhr - hourAngle(fajrAngle))
        val sunrise = fixHour(dhuhr - hourAngle(sunriseAngle))
        val asr = fixHour(dhuhr + asrHA)
        val sunset = fixHour(dhuhr + hourAngle(sunriseAngle))
        val maghrib = fixHour(dhuhr + hourAngle(maghribAngle))
        val isha = fixHour(dhuhr + hourAngle(ishaAngle))

        var nightLength = fajr + 24.0 - sunset
        if (nightLength > 24.0) nightLength -= 24.0
        val midnight = fixHour(sunset + nightLength / 2.0)

        return PrayerTimings(fajr, sunrise, dhuhr, asr, sunset, maghrib, isha, midnight)
    }

    fun formatHourMinutes(decimalHour: Double): String {
        val totalMinutes = (decimalHour * 60).roundToInt()
        val h = (totalMinutes / 60) % 24
        val m = totalMinutes % 60
        return String.format("%02d:%02d", h, m)
    }

    fun decimalHourToMillisToday(baseCal: Calendar, decimalHour: Double): Long {
        val totalMinutes = (decimalHour * 60).roundToInt()
        val h = (totalMinutes / 60) % 24
        val m = totalMinutes % 60
        return (baseCal.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun findNextPrayer(
        nowCal: Calendar,
        timings: PrayerTimings,
        prefs: UserPreferencesRepository.Prefs
    ): Pair<String, String> {
        val nowMillis = nowCal.timeInMillis
        val candidates = listOf(
            Triple("Fajr", timings.fajr, prefs.fajrEnabled),
            Triple("Dhuhr", timings.dhuhr, prefs.dhuhrEnabled),
            Triple("Asr", timings.asr, prefs.asrEnabled),
            Triple("Maghrib", timings.maghrib, prefs.maghribEnabled),
            Triple("Isha", timings.isha, prefs.ishaEnabled)
        )
        for ((name, decHour, enabled) in candidates) {
            if (enabled && decimalHourToMillisToday(nowCal, decHour) > nowMillis) {
                return name to formatHourMinutes(decHour)
            }
        }
        return "Fajr" to formatHourMinutes(timings.fajr)
    }
}
