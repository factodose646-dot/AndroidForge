package com.shia512.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF1A35),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF40040B),
    onPrimaryContainer = Color(0xFFFFD9DD),
    secondary = Color(0xFFE11D48),
    background = Color(0xFF050507),
    surface = Color(0xFF0D0D12),
    onBackground = Color(0xFFF3F4F6),
    onSurface = Color(0xFFF3F4F6)
)

@Composable
fun Shia512Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
