package com.shia512.app.ui.tasbeeh

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shia512.app.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.launch

@Composable
fun TasbeehScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { UserPreferencesRepository(context) }
    val prefs by repo.prefsFlow.collectAsState(initial = UserPreferencesRepository.DefaultPrefs)
    val count = prefs.tasbeehCount

    val phaseText = when {
        count < 34 -> "Step 1: Allahu Akbar (34x)"
        count < 67 -> "Step 2: Alhamdulillah (33x)"
        count < 100 -> "Step 3: SubhanAllah (33x)"
        else -> "Tasbih Fatima Zahra (s.a.) Complete!"
    }

    fun vibrateTick() {
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF14090D)),
            border = BorderStroke(1.dp, Color(0x66FF1A35)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Tasbih Sayyida Fatima Zahra (s.a.)", color = Color(0xFFFF4D64), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(phaseText, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Button(
            onClick = {
                vibrateTick()
                scope.launch { repo.setTasbeehCount(count + 1) }
            },
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B0910)),
            border = BorderStroke(3.dp, Color(0xFFFF1A35)),
            modifier = Modifier.size(220.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(count.toString(), color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Black)
                Text("TAP TO COUNT", color = Color(0xFFFF4D64), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        OutlinedButton(
            onClick = { scope.launch { repo.setTasbeehCount(0) } },
            border = BorderStroke(1.dp, Color(0xFFFF1A35)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset Counter", color = Color.White)
        }
    }
}
