package com.shia512.app.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shia512.app.data.calculation.JafariCalculator
import com.shia512.app.data.farman.FarmanRepository
import com.shia512.app.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    onOpenFarman: () -> Unit,
    onOpenTasbeeh: () -> Unit,
    onOpenAlarms: () -> Unit
) {
    val context = LocalContext.current
    val repo = remember { UserPreferencesRepository(context) }
    val prefs by repo.prefsFlow.collectAsState(initial = UserPreferencesRepository.DefaultPrefs)

    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val cal = remember(nowMillis) { Calendar.getInstance().apply { timeInMillis = nowMillis } }
    val tzOffsetHours = cal.timeZone.getOffset(nowMillis) / 3600000.0
    val timings = remember(
        cal.get(Calendar.DAY_OF_YEAR),
        prefs.latitude,
        prefs.longitude,
        prefs.isTehranMethod
    ) {
        JafariCalculator.calculate(
            year = cal.get(Calendar.YEAR),
            month = cal.get(Calendar.MONTH) + 1,
            day = cal.get(Calendar.DAY_OF_MONTH),
            latitude = prefs.latitude,
            longitude = prefs.longitude,
            tzOffsetHours = tzOffsetHours,
            isTehranMethod = prefs.isTehranMethod
        )
    }

    val prayerRows = listOf(
        Triple("Fajr", "فجر", JafariCalculator.formatHourMinutes(timings.fajr)),
        Triple("Sunrise", "طلوع آفتاب", JafariCalculator.formatHourMinutes(timings.sunrise)),
        Triple("Dhuhr", "ظہر", JafariCalculator.formatHourMinutes(timings.dhuhr)),
        Triple("Asr", "عصر", JafariCalculator.formatHourMinutes(timings.asr)),
        Triple("Maghrib", "مغرب", JafariCalculator.formatHourMinutes(timings.maghrib)),
        Triple("Isha", "عشاء", JafariCalculator.formatHourMinutes(timings.isha))
    )

    val nextReminder = remember(nowMillis, timings, prefs) {
        JafariCalculator.findNextPrayer(cal, timings, prefs)
    }
    val dailyFarman = remember(cal.get(Calendar.DAY_OF_YEAR)) { FarmanRepository.getDailyFarman() }
    val clockFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val dateFormat = remember { SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        // 1. Live Clock & Selected City Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14080C)),
                border = BorderStroke(1.dp, Color(0x66FF1A35)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${prefs.cityName} • ${prefs.countryName}",
                        color = Color(0xFFFF4D64),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = clockFormat.format(Date(nowMillis)),
                        color = Color.White,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = dateFormat.format(Date(nowMillis)),
                        color = Color(0xFFA1A1AA),
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 2. Daily Farman-e-Masoomeen Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF12090D)),
                border = BorderStroke(1.dp, Color(0x88FF1A35)),
                shape = RoundedCornerShape(18.dp),
                onClick = onOpenFarman
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FARMAN-E-MASOOMEEN",
                        color = Color(0xFFFF1A35),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = dailyFarman.arabic,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = dailyFarman.urdu,
                        color = Color(0xFFE4E4E7),
                        fontSize = 14.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${dailyFarman.masoomEn} — ${dailyFarman.source}",
                        color = Color(0xFFA1A1AA),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // 3. Next Prayer Reminder & Quick Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF20080D)),
                border = BorderStroke(1.5.dp, Color(0xFFFF1A35)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("NEXT PRAYER", color = Color(0xFFFF4D64), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(nextReminder.first, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text("Scheduled: ${nextReminder.second}", color = Color(0xFFD4D4D8), fontSize = 12.sp)
                    }
                    Button(
                        onClick = onOpenAlarms,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1A35))
                    ) {
                        Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Alarms", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 4. Prayer Timings Rows
        items(prayerRows) { (nameEn, nameUr, timeStr) ->
            val isNext = nameEn.equals(nextReminder.first, ignoreCase = true)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isNext) Color(0xFF2B0B12) else Color(0xFF0E0E13)
                ),
                border = BorderStroke(1.dp, if (isNext) Color(0xFFFF1A35) else Color(0xFF231215)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(nameEn, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(nameUr, color = Color(0xFFA1A1AA), fontSize = 12.sp)
                    }
                    Text(
                        text = timeStr,
                        color = if (isNext) Color(0xFFFF1A35) else Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // 5. Quick Tasbeeh & Developer Credit Footer
        item {
            OutlinedButton(
                onClick = onOpenTasbeeh,
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, Color(0x66FF1A35))
            ) {
                Text("Open Digital Tasbeeh (Fatima Zahra s.a.)", color = Color.White)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "App developed by Syed Sadaf Hussain Zaidi",
                color = Color(0xFFA1A1AA),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
