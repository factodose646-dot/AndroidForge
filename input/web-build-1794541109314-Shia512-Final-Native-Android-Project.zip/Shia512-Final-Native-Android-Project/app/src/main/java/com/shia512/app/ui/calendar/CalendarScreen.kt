package com.shia512.app.ui.calendar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CalendarScreen() {
    val cal = Calendar.getInstance()
    val islamicCal = android.icu.util.IslamicCalendar()
    val hijriMonths = listOf(
        "Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani",
        "Jumada al-Ula", "Jumada al-Akhirah", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    )
    val hDay = islamicCal.get(android.icu.util.Calendar.DAY_OF_MONTH)
    val hMonth = hijriMonths[islamicCal.get(android.icu.util.Calendar.MONTH).coerceIn(0, 11)]
    val hYear = islamicCal.get(android.icu.util.Calendar.YEAR)
    val isFriday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A080D)),
            border = BorderStroke(1.5.dp, Color(0xFFFF1A35)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("ISLAMIC & GREGORIAN DATE", color = Color(0xFFFF4D64), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("$hDay $hMonth $hYear AH", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(cal.time), color = Color(0xFFD4D4D8), fontSize = 13.sp)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = if (isFriday) Color(0xFF280910) else Color(0xFF100E13)),
            border = BorderStroke(1.dp, Color(0x66FF1A35)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isFriday) "TODAY IS JUMU'AH (FRIDAY)" else "Upcoming Jumu'ah Highlight",
                    color = Color(0xFFFF1A35),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Remember to verify both calculated Shia Ja'fari Dhuhr time and your local mosque / imambargah Jamaat time.",
                    color = Color(0xFFA1A1AA),
                    fontSize = 12.sp
                )
            }
        }
    }
}
