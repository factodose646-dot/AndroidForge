package com.shia512.app.alarm

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.shia512.app.R
import com.shia512.app.ui.alarm.PrayerAlarmActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PrayerAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val prayerId = intent.getStringExtra("PRAYER_ID") ?: "prayer"
        val prayerName = intent.getStringExtra("PRAYER_NAME") ?: "PRAYER"

        when (intent.action) {
            "com.shia512.app.ACTION_DISMISS_ALARM" -> {
                notificationManager.cancel(51200)
                return
            }
            "com.shia512.app.ACTION_SNOOZE_ALARM" -> {
                notificationManager.cancel(51200)
                PrayerAlarmScheduler(context).scheduleSnoozeAlarm(prayerName, 5)
                return
            }
        }

        // Reschedule tomorrow's occurrence cleanly so daily alarms never lapse
        if (prayerId != "snooze" && prayerId != "test") {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    PrayerAlarmScheduler(context).rescheduleAllFromPreferences()
                } finally {
                    pendingResult.finish()
                }
            }
        }

        val fullScreenIntent = Intent(context, PrayerAlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("PRAYER_ID", prayerId)
            putExtra("PRAYER_NAME", prayerName)
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            51210,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val dismissIntent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = "com.shia512.app.ACTION_DISMISS_ALARM"
        }
        val dismissPi = PendingIntent.getBroadcast(
            context,
            51211,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = "shia512_alarm_channel_v2"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                channelId,
                "Shia512 Prayer Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Exact Shia Ja'fari prayer reminders"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 300, 500)
                setSound(soundUri, attrs)
                setBypassDnd(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("$prayerName TIME — Shia512")
            .setContentText("Namaz ka waqt ho gaya hai")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .addAction(0, "STOP", dismissPi)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(51200, notification)

        // Respect Android 14+ policy: launch activity directly only when permitted; otherwise notification handles it
        val canFullScreen = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            notificationManager.canUseFullScreenIntent()
        } else true

        if (canFullScreen) {
            try {
                context.startActivity(fullScreenIntent)
            } catch (_: Exception) {
                // High-priority full-screen notification remains active as fallback
            }
        }
    }
}
