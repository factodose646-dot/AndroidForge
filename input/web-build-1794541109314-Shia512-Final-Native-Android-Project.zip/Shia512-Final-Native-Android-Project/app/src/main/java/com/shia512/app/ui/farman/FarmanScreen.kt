package com.shia512.app.ui.farman

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shia512.app.data.farman.FarmanRepository

@Composable
fun FarmanScreen() {
    var query by remember { mutableStateOf("") }
    val daily = remember { FarmanRepository.getDailyFarman() }
    val allFarmans = remember { FarmanRepository.getAllFarmans() }
    val filtered = remember(query, allFarmans) {
        if (query.isBlank()) allFarmans
        else allFarmans.filter {
            it.masoomEn.contains(query, ignoreCase = true) ||
                it.english.contains(query, ignoreCase = true) ||
                it.urdu.contains(query, ignoreCase = true) ||
                it.source.contains(query, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1F080D)),
                border = BorderStroke(1.5.dp, Color(0xFFFF1A35)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("TODAY'S FARMAN-E-MASOOMEEN", color = Color(0xFFFF4D64), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Text(daily.arabic, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text(daily.urdu, color = Color(0xFFE4E4E7), fontSize = 15.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text(daily.english, color = Color(0xFFD4D4D8), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("${daily.masoomEn} • ${daily.source}", color = Color(0xFFFF4D64), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search Farman or Source") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(filtered) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0E0E13)),
                border = BorderStroke(1.dp, Color(0xFF281217)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(item.masoomEn, color = Color(0xFFFF4D64), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(item.arabic, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text(item.urdu, color = Color(0xFFE4E4E7), fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("Source: ${item.source}", color = Color(0xFFA1A1AA), fontSize = 11.sp)
                }
            }
        }
    }
}
